const express = require('express');
const { Pool } = require('pg'); // Thư viện kết nối PostgreSQL
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 10000;

app.use(express.json());
app.use(express.static(require('path').join(__dirname, 'public')));

// Dashboard admin API. Set DASHBOARD_ADMIN_KEY in Render for a lightweight shared secret.
const activityLog = [];
const adminGuard = (req, res, next) => {
    const expected = process.env.DASHBOARD_ADMIN_KEY;
    if (!expected) return next();
    if (req.headers['x-admin-key'] !== expected) return res.status(401).json({ error: 'Unauthorized' });
    next();
};
const logActivity = (action, target, detail, actor = 'Dashboard admin') => {
    activityLog.unshift({ id: Date.now(), action, target, detail, actor, createdAt: new Date().toISOString() });
    if (activityLog.length > 100) activityLog.pop();
};
const keyView = (row) => ({
    id: row.id, key: row.key, api: row.api, status: row.status,
    durationInDays: row.duration_in_days ?? row.durationInDays ?? 0,
    expiresAt: row.expires_at ?? row.expiresAt ?? null,
    hwid: row.hwid ?? null, banInfo: row.ban_info ?? row.banInfo ?? null,
    createdAt: row.created_at ?? row.createdAt ?? null,
    firstLoginAt: row.first_login_at ?? row.firstLoginAt ?? null
});

app.use('/api/dashboard', adminGuard);
app.get('/api/dashboard/stats/overview', async (req, res) => {
    try {
        const [total, active, banned, apis, recent, soon] = await Promise.all([
            pool.query('SELECT COUNT(*)::int AS count FROM keys'),
            pool.query("SELECT COUNT(*)::int AS count FROM keys WHERE status = 'active' AND (expires_at IS NULL OR expires_at > NOW())"),
            pool.query("SELECT COUNT(*)::int AS count FROM keys WHERE status = 'banned'"),
            pool.query("SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE status = 'active')::int AS running FROM apis"),
            pool.query("SELECT COUNT(*)::int AS count FROM keys WHERE created_at >= NOW() - INTERVAL '24 hours'"),
            pool.query("SELECT COUNT(*)::int AS count FROM keys WHERE expires_at IS NOT NULL AND expires_at BETWEEN NOW() AND NOW() + INTERVAL '3 days'")
        ]);
        res.json({ totalKeys: total.rows[0].count, activeKeys: active.rows[0].count, bannedKeys: banned.rows[0].count, apiCount: apis.rows[0].total, runningApis: apis.rows[0].running, requests24h: recent.rows[0].count, expiringSoon: soon.rows[0].count });
    } catch (e) { res.status(500).json({ error: e.message }); }
});
app.get('/api/dashboard/keys', async (req, res) => {
    const { apiKey, status, search, page = 1, pageSize = 25 } = req.query;
    const params = []; const where = [];
    if (apiKey) { params.push(apiKey); where.push(`api = $${params.length}`); }
    if (status && status !== 'all') { params.push(status); where.push(`status = $${params.length}`); }
    if (search) { params.push(`%${search}%`); where.push(`(key ILIKE $${params.length} OR COALESCE(hwid, '') ILIKE $${params.length})`); }
    const clause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const limit = Math.min(100, Math.max(1, Number(pageSize))); const offset = (Math.max(1, Number(page)) - 1) * limit;
    try {
        const count = await pool.query(`SELECT COUNT(*)::int AS count FROM keys ${clause}`, params);
        const rows = await pool.query(`SELECT * FROM keys ${clause} ORDER BY created_at DESC NULLS LAST LIMIT ${limit} OFFSET ${offset}`, params);
        res.json({ items: rows.rows.map(keyView), total: count.rows[0].count, page: Number(page), pageSize: limit });
    } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/dashboard/keys', async (req, res) => {
    const { apiKey, quantity = 1, durationInDays = 30, prefix = '', randomChunks = 4 } = req.body || {};
    if (!apiKey) return res.status(400).json({ error: 'apiKey is required' });
    try {
        const crypto = require('crypto'); const api = await pool.query('SELECT * FROM apis WHERE api_key = $1', [apiKey]);
        if (!api.rows.length) return res.status(404).json({ error: 'API not found' });
        const created = []; const count = Math.min(50, Math.max(1, Number(quantity))); const chunks = Math.min(8, Math.max(1, Number(randomChunks)));
        for (let i = 0; i < count; i++) { const random = crypto.randomBytes(chunks * 2).toString('hex').toUpperCase().match(/.{4}/g).join('-'); const key = `${String(prefix).replace(/-$/, '')}${prefix ? '-' : ''}${random}`; const r = await pool.query('INSERT INTO keys (key, api, status, duration_in_days) VALUES ($1, $2, $3, $4) RETURNING *', [key, apiKey, 'active', Number(durationInDays)]); created.push(keyView(r.rows[0])); }
        logActivity('create-key', api.rows[0].app_name, `Created ${created.length} key(s)`); res.status(201).json({ items: created });
    } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/dashboard/keys/:key/ban', async (req, res) => { try { const { reason = 'No reason provided', days } = req.body || {}; const unbanDate = days ? new Date(Date.now() + Number(days) * 86400000).toISOString() : 'Vĩnh viễn'; const banInfo = { reason, bannedBy: req.headers['x-actor'] || 'dashboard', bannedAt: new Date().toISOString(), unbanDate }; const r = await pool.query('UPDATE keys SET status=$1, ban_info=$2 WHERE key=$3 RETURNING *', ['banned', JSON.stringify(banInfo), req.params.key]); if (!r.rows.length) return res.status(404).json({ error: 'Key not found' }); logActivity('ban-key', req.params.key, reason); res.json(keyView(r.rows[0])); } catch(e) { res.status(500).json({ error:e.message }); } });
app.post('/api/dashboard/keys/:key/unban', async (req, res) => { try { const r = await pool.query('UPDATE keys SET status=$1, ban_info=NULL WHERE key=$2 RETURNING *', ['active', req.params.key]); if (!r.rows.length) return res.status(404).json({ error:'Key not found' }); logActivity('unban-key', req.params.key, req.body?.reason || 'Unbanned'); res.json(keyView(r.rows[0])); } catch(e) { res.status(500).json({ error:e.message }); } });
app.post('/api/dashboard/keys/:key/adjust-days', async (req, res) => { try { const days = Math.abs(Number(req.body?.days || 0)) * (req.body?.direction === 'remove' ? -1 : 1); const r = await pool.query("UPDATE keys SET duration_in_days = GREATEST(0, COALESCE(duration_in_days, 0) + $1), expires_at = CASE WHEN expires_at IS NULL THEN NULL ELSE expires_at + ($1 * INTERVAL '1 day') END WHERE key=$2 RETURNING *", [days, req.params.key]); if (!r.rows.length) return res.status(404).json({ error:'Key not found' }); logActivity('adjust-days', req.params.key, `${days} days`); res.json(keyView(r.rows[0])); } catch(e) { res.status(500).json({ error:e.message }); } });
app.post('/api/dashboard/keys/:key/reset-hwid', async (req, res) => { try { const r = await pool.query('UPDATE keys SET hwid=NULL, first_login_at=NULL, expires_at=NULL WHERE key=$1 RETURNING *', [req.params.key]); if (!r.rows.length) return res.status(404).json({ error:'Key not found' }); logActivity('reset-hwid', req.params.key, 'HWID reset'); res.json(keyView(r.rows[0])); } catch(e) { res.status(500).json({ error:e.message }); } });
app.delete('/api/dashboard/keys/:key', async (req, res) => { try { const r = await pool.query('DELETE FROM keys WHERE key=$1 RETURNING key', [req.params.key]); if (!r.rows.length) return res.status(404).json({ error:'Key not found' }); logActivity('delete-key', req.params.key, 'Deleted'); res.json({ success:true }); } catch(e) { res.status(500).json({ error:e.message }); } });
app.get('/api/dashboard/apis', async (req, res) => { try { const r = await pool.query('SELECT a.*, COUNT(k.key)::int AS key_count FROM apis a LEFT JOIN keys k ON k.api=a.api_key GROUP BY a.id ORDER BY a.created_at DESC NULLS LAST'); res.json(r.rows.map(x => ({ id:x.id, appName:x.app_name, apiKey:x.api_key, ownerId:x.owner_id, status:x.status, keyCount:x.key_count, createdAt:x.created_at }))); } catch(e) { res.status(500).json({error:e.message}); } });
app.post('/api/dashboard/apis', async (req,res) => { try { const crypto=require('crypto'); const { appName, ownerId='dashboard' }=req.body||{}; if(!appName) return res.status(400).json({error:'appName is required'}); const apiKey=crypto.randomBytes(12).toString('hex'); const r=await pool.query('INSERT INTO apis (app_name, api_key, owner_id, status) VALUES ($1,$2,$3,$4) RETURNING *',[appName,apiKey,ownerId,'active']); logActivity('create-api',appName,'Created API'); res.status(201).json({appName:r.rows[0].app_name,apiKey:r.rows[0].api_key,ownerId:r.rows[0].owner_id,status:r.rows[0].status,createdAt:r.rows[0].created_at}); } catch(e){res.status(500).json({error:e.message});} });
app.patch('/api/dashboard/apis/:appName/status', async (req,res)=>{ try { const status=req.body?.status === 'stopped' ? 'stopped' : 'active'; const r=await pool.query('UPDATE apis SET status=$1 WHERE app_name=$2 RETURNING *',[status,req.params.appName]); if(!r.rows.length)return res.status(404).json({error:'API not found'}); logActivity('toggle-api',req.params.appName,status); res.json(r.rows[0]); }catch(e){res.status(500).json({error:e.message});} });
app.delete('/api/dashboard/apis/:appName', async (req,res)=>{ try { const r=await pool.query('DELETE FROM apis WHERE app_name=$1 RETURNING app_name',[req.params.appName]); if(!r.rows.length)return res.status(404).json({error:'API not found'}); logActivity('delete-api',req.params.appName,'Deleted'); res.json({success:true}); }catch(e){res.status(500).json({error:e.message});} });
app.get('/api/dashboard/activity-log', (req,res)=>res.json(activityLog));
app.get('/api/dashboard/support-users', (req,res)=>res.json((process.env.SUPPORT_USERS || '').split(',').map(x=>x.trim()).filter(Boolean)));
app.get('/api/dashboard/health', (req,res)=>res.json({ok:true, service:'key-manager-api'}));


// Kết nối tới Supabase Database qua biến môi trường DATABASE_URL
const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: { rejectUnauthorized: false } // Bắt buộc phải có khi dùng Supabase
});

app.post('/api/validate', async (req, res) => {
    const { key, hwid } = req.body;

    if (!key || !hwid) {
        return res.status(400).json({
            success: false,
            message: 'Thiếu key hoặc HWID.'
        });
    }

    try {
        // 1. Tìm Key trong Database
        const keyResult = await pool.query('SELECT * FROM keys WHERE key = $1', [key]);
        
        if (keyResult.rows.length === 0) {
            return res.json({ success: false, message: 'Key không hợp lệ.' });
        }

        let keyData = keyResult.rows[0];

        // 2. Kiểm tra API (xem app có bị tạm dừng/vô hiệu hóa không)
        const apiResult = await pool.query('SELECT * FROM apis WHERE api_key = $1', [keyData.api]);
        
        if (apiResult.rows.length === 0 || apiResult.rows[0].status !== 'active') {
            return res.json({ success: false, message: 'API của key này đã bị vô hiệu hóa.' });
        }

        // 3. Kiểm tra Key có bị ban không
        if (keyData.status === 'banned') {
            let reason = 'Không rõ';
            let unbanDateStr = 'Vĩnh viễn';
            
            // Xử lý dữ liệu JSONB ban_info từ Postgres
            if (keyData.ban_info) {
                reason = keyData.ban_info.reason || reason;
                if (keyData.ban_info.unbanDate && keyData.ban_info.unbanDate !== 'Vĩnh viễn') {
                    unbanDateStr = new Date(keyData.ban_info.unbanDate).toLocaleDateString('vi-VN');
                }
            }
            
            return res.json({
                success: false,
                message: `Key đã bị khóa. Lý do: ${reason}. Mở khóa vào: ${unbanDateStr}`
            });
        }

        // 4. XỬ LÝ ĐĂNG NHẬP LẦN ĐẦU → BIND HWID
        if (!keyData.hwid) {
            const duration = keyData.duration_in_days || 0;
            const expires = new Date();
            expires.setDate(expires.getDate() + duration);
            const firstLogin = new Date();

            // Cập nhật HWID và thời gian vào Database
            await pool.query(
                'UPDATE keys SET hwid = $1, first_login_at = $2, expires_at = $3 WHERE key = $4',
                [hwid, firstLogin, expires, key]
            );

            return res.json({
                success: true,
                message: 'Xác thực lần đầu thành công!',
                expires: expires.toISOString()
            });
        }

        // 5. Kiểm tra HWID có khớp không
        if (keyData.hwid !== hwid) {
            return res.json({
                success: false,
                message: 'HWID không khớp.'
            });
        }

        // 6. Kiểm tra hạn sử dụng
        if (keyData.expires_at && new Date(keyData.expires_at) < new Date()) {
            return res.json({
                success: false,
                message: 'Key đã hết hạn.'
            });
        }

        // 7. Mọi thứ hợp lệ
        return res.json({
            success: true,
            message: 'Xác thực thành công!',
            expires: keyData.expires_at
        });

    } catch (err) {
        console.error('Lỗi Database: ', err);
        return res.status(500).json({
            success: false,
            message: 'Lỗi máy chủ.'
        });
    }
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`API running on port ${PORT}`);
});

// Tạm comment phần bot discord lại để Render chỉ chạy API cho nhẹ
// require('./bot.js');
// require('./deploy-commands.js');
