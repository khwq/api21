# Deep Space Key Manager

Dashboard quản lý key/API chạy chung với Express API hiện tại.

## Chạy local

```bash
npm install
npm start
```

Mở `http://localhost:10000`.

## Render

- **Build Command:** `npm install`
- **Start Command:** `npm start`
- **Environment:** `DATABASE_URL` bắt buộc; `PORT` do Render tự cấp.
- Tuỳ chọn: `DASHBOARD_ADMIN_KEY` để yêu cầu header `x-admin-key` cho endpoint dashboard.

API xác thực hiện tại:

```text
POST /api/validate
```

Dashboard dùng các endpoint dưới `/api/dashboard/*` để tránh xung đột với endpoint validate:

- `GET /api/dashboard/stats/overview`
- `GET/POST /api/dashboard/keys`
- `POST /api/dashboard/keys/:key/ban`
- `POST /api/dashboard/keys/:key/unban`
- `POST /api/dashboard/keys/:key/adjust-days`
- `POST /api/dashboard/keys/:key/reset-hwid`
- `DELETE /api/dashboard/keys/:key`
- `GET/POST /api/dashboard/apis`
- `PATCH /api/dashboard/apis/:appName/status`
- `DELETE /api/dashboard/apis/:appName`
- `GET /api/dashboard/activity-log`

## Lưu ý bảo mật

Discord OAuth2 chưa được triển khai trong bản này. Trước khi public dashboard, đặt `DASHBOARD_ADMIN_KEY` và thêm lớp OAuth/session ở reverse proxy hoặc backend. Không đưa `DATABASE_URL` lên frontend.
